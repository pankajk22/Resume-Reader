# from __future__ import print_function
# import fitz           
# import re   
# import camelot

# doc = fitz.open("Resume_3.pdf")
# tables = camelot.read_pdf("Resume_3.pdf")
# print("total tables extracted:"+str(tables.n))
# page=len(doc)
# print("Total Number of pages: "+str(page))
# i=0
# pagetext=""
# prevpagecharlen=0
# while(i<page):
#     imagelist=doc.getPageImageList(0, full=True)
#     fontlist = doc.getPageFontList(i)
#     pagetext= pagetext+doc.getPageText(i)
#     totalcharlen=len(pagetext)
#     currpagelen=totalcharlen-prevpagecharlen
#     prevpagecharlen=totalcharlen
#     print("No of text characters in Page No- "+str(i)+" is "+str(currpagelen))
#     if fontlist:
#         print("fonts used on page", i)
#         for font in fontlist:
#             print("xref=%s, gen=%s, type=%s, basefont=%s, name=%s" % (font[0], font[1], font[2], font[3], font[4]))
#     i=i+1
# print("total Number of images in resume:"+str(len(imagelist)))
# numberofimages=str(len(imagelist))
# print(pagetext)
# # /[a-z0-9_\-\+\.]+@[a-z0-9\-]+\.([a-z]{2,4})(?:\.[a-z]{2})?/i
# if((pagetext.find('@')!=-1)or(pagetext.find('mail')!=-1)):
#     print("Email Address Found")
#     emails=re.findall('[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+',pagetext)
#     print(emails[0])
# if(pagetext.find('www.linkedin.com')!=-1):
#     print("LinkedIn Profile found")
#     linkedin=re.findall('https*://www.linkedin.com/in/[a-z0-9_]+',pagetext)
#     print(linkedin)
# phone1=re.findall('(\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4})',pagetext)
# phone2=re.findall('(\+\d{1,3}-*\d{2,3}-*\d{3,6}[-*\d{4}]?)',pagetext)
# print(phone1)
# print(phone2)

        
    


# print("Executing python file")
from __future__ import print_function
from tika import parser
import fitz  
import sys
import nltk
import json
import os
import re
import camelot
import csv

class Resume:
    def __init__(self):
        self.Name='Name'
        self.Email='None'
        self.phoneno='None'
        self.linkedinProf='None'
        self.characters='None'
        self.fonts='None'
        self.totaltables='0'
        self.totalimages='0'

fields = ['Name', 'E-Mail Address', 'Phone Number', 'LinkedIn Profile','Total No of Text Characters on each Page','Fonts','Total No of tables','Total No of images'] 
filename = "download/output.csv"

try:
    file = sys.argv[1]

except:
    print("ERROR")
   
    sys.exit(1)

obj1=Resume()                     
doc = fitz.open(file)
tables = camelot.read_pdf(file)
# print("total tables extracted:"+str(tables.n))
obj1.totaltables=str(tables.n)
page=len(doc)
# print("Total Number of pages: "+str(page))
i=0
pagetext=""
fontinfo=""
charinfo=""
prevpagecharlen=0
while(i<page):
    # print("In while loop!!")
    fontinfo=fontinfo+"Fonts used in Page "+str(i)+":-\n"
    # print("fontinfo-"+fontinfo)
    imagelist=doc.getPageImageList(0, full=True)
    fontlist = doc.getPageFontList(i)
    pagetext= pagetext+doc.getPageText(i)
    totalcharlen=len(pagetext)
    currpagelen=totalcharlen-prevpagecharlen
    prevpagecharlen=totalcharlen
    # print("No of text characters in Page No- "+str(i)+" is "+str(currpagelen))
    charinfo=charinfo+"Page "+str(i)+" :- "+str(currpagelen)+"\n"
    if fontlist:
        # print("fonts used on page", i)
        for font in fontlist:
            fontinfo=fontinfo+"xref :"+str(font[0])+"gen :"+str(font[1])+"type :"+str(font[2])+"basement :"+str(font[3])+"basefont :"+str(font[4])+"name :"+str(font[4])+"\n"
            # print("xref=%s, gen=%s, type=%s, basefont=%s, name=%s" % (font[0], font[1], font[2], font[3], font[4]))
    i=i+1
obj1.characters=charinfo
obj1.fonts=fontinfo
# print("total Number of images in resume:"+str(len(imagelist)))
obj1.totalimages=str(len(imagelist))
# print(pagetext)
temptext=pagetext
newstr=temptext.replace("\n","")
newstr1=newstr.replace("  "," ")
# print(newstr)
splitted=newstr1.split()
# print(splitted)
if((splitted[0]=="RESUME")or (splitted[0]=="Resume")or (splitted[0]=="resume")):
    name=splitted[1]+" "+splitted[2]
else:
    name=splitted[0]+" "+splitted[1]
# print(name)
obj1.Name=name
# /[a-z0-9_\-\+\.]+@[a-z0-9\-]+\.([a-z]{2,4})(?:\.[a-z]{2})?/i
if((pagetext.find('@')!=-1)or(pagetext.find('mail')!=-1)):
    # print("Email Address Found")
    emails=re.findall('[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+',pagetext)
    # print(emails[0])
    obj1.Email=emails[0]
if(pagetext.find('www.linkedin.com')!=-1):
    # print("LinkedIn Profile found")
    linkedin=re.findall('https*://www.linkedin.com/in/[a-z0-9_]+',pagetext)
    # print(linkedin)
    obj1.linkedinProf=linkedin[0]
phone1=re.findall('(\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4})',pagetext)
phone2=re.findall('(\+\d{1,3}-*\d{2,3}-*\d{3,6}[-*\d{4}]?)',pagetext)
if(len(phone1)>0):
    obj1.phoneno=phone1[0]
if(len(phone2)>0):
    obj1.phoneno=phone2[0]
rows=[[obj1.Name,obj1.Email,obj1.phoneno,obj1.linkedinProf,obj1.characters,obj1.fonts,obj1.totaltables,obj1.totalimages]]
with open(filename,'w') as csvfile:
    csvwriter = csv.writer(csvfile) 
    csvwriter.writerow(fields) 
    csvwriter.writerows(rows)
print("***********************INFORMATION IS READY*******************")
# print(obj1.Name)
# print(obj1.Email)
# print(obj1.phoneno)
# print(obj1.linkedinProf)
# print(obj1.fonts)
# print(obj1.characters)
# print(obj1.totalimages)
# print(obj1.totaltables)
