<html>
<button onclick="document.location = 'delfile.php'">HOME</button> 
<?php
    session_start();
    $filename=$_SESSION["fileloc"];
    echo("<br>");
    include ( 'C:/xampp/htdocs/Internship/ResumeReader/PdfToText-master/PdfToText.phpclass' );
    $pdf	=  new PdfToText ($filename) ;
    $command = escapeshellcmd('python textextract.py ');
    $arg=$command.escapeshellarg($filename);
    // echo $arg;
    $output = shell_exec($arg);
    echo $output
?>

<p>Click on the image to download CSV File:<p>
<a href="download/output.csv" download>
  <img src="download.png" alt="W3Schools" width="104" height="142">
</a>
</html>