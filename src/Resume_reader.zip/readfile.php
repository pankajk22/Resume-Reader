<!-- ([+0-9-]{5}[0-9-]{3}[0-9]{6}) -->
<!-- ([+0-9-]{4}[0-9-]{5}[0-9]{5}) --For indian phone numbers-->


<html>
<button onclick="document.location = 'addfile.php'">HOME</button> 
<?php  
session_start(); 



if ( isset( $_FILES['pdfFile'] ) ) {
	if ($_FILES['pdfFile']['type'] == "application/pdf") {
		$source_file = $_FILES['pdfFile']['tmp_name'];
		$dest_file = "upload/".$_FILES['pdfFile']['name'];
        $_SESSION["fileloc"]=$dest_file;
		if (file_exists($dest_file)) {
			print "The file name already exists!!";
		}
		else {
			move_uploaded_file( $source_file, $dest_file )
			or die ("Error!!");
			if($_FILES['pdfFile']['error'] == 0) {
				print "Pdf file uploaded successfully!";
				print "\n <b><u>Details : </u></b><br/>";
				print "File Name : ".$_FILES['pdfFile']['name']."<br.>"."<br/>";
				print "File Size : ".$_FILES['pdfFile']['size']." bytes"."<br/>";
                print "File location : upload/".$_FILES['pdfFile']['name']."<br/>";
                echo"
                <form action='resumeread.php'>
                    <input type='submit' value='Parse the resume' />
                </form>
                ";
                echo"
                <form action='addfile.php'>
                    <input type='submit' value='Home' />
                </form>
                ";
			}
		}
	}
	else {
		if ( $_FILES['pdfFile']['type'] != "application/pdf") {
			print "Error occured while uploading file : ".$_FILES['pdfFile']['name']."<br/>";
			print "Invalid  file extension, should be pdf !!"."<br/>";
			print "Error Code : ".$_FILES['pdfFile']['error']."<br/>";
		}
	}
}

?>
</html>