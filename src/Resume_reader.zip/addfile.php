<!-- C:\xampp\htdocs\Internship\ResumeReader\Resume_1.pdf -->
<html>

	<form action="readfile.php" method="POST" enctype="multipart/form-data">
         <input type="file" name="pdfFile" />
         <input type="submit"/>
    </form>
</html>
